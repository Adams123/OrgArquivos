#ifndef _RUN_LENGHT_H
#define _RUN_LENGHT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int eol(int c, FILE *fp);
int skipline(FILE *fp);
void cRunLenght(FILE *fp);
void dRunLenght(FILE *fp);
#endif // _RUN
